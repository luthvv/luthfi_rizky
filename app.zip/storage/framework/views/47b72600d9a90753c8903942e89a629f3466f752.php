<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/scrollreveal"></script>
    <title>Luthfi Rizky</title>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        bg1: '#DBD9D7',
                        bg2: '#D6C5BD',
                        primary: '#2A3145',
                        secondary: '#A25D50'
                    },
                }
            }
        }
    </script>
</head>

<body>
    <div class="bg-bg1 miring overflow-hidden relative z-50">
        <div class="relative top-[65px] rata pt-[30px] px-[150px] h-full pr-[150px]">
            <div class="flex gap-[40px] text-[30px]">
                <div class="cursor-pointer fonseca text-white relative dot">Home</div>
                <div class="cursor-pointer fonseca opacity-60 hover:opacity-100 transition duration-150 text-white">
                    Works
                </div>
                <div class="cursor-pointer fonseca opacity-60 hover:opacity-100 transition duration-150 text-white">
                    Service
                </div>
            </div>

            <div class="h-full flex justify-between">
                <div class="self-center relative z-50 mb-[80px]">
                    <div class="flex items-center gap-5 mb-[70px] text-4xl text-primary">
                        <div class="ig cursor-pointer hover:text-secondary duration-300">
                            <i class="fa-brands fa-instagram"></i>
                        </div>
                        <div class="linked cursor-pointer hover:text-secondary duration-300">
                            <i class="fa-brands fa-linkedin"></i>
                        </div>
                        <div class="git cursor-pointer hover:text-secondary duration-300">
                            <i class="fa-brands fa-github"></i>
                        </div>
                    </div>

                    <div class="w-[100px] h-[8px] bg-secondary mb-[30px]"></div>

                    <div class="fonseca name text-[130px] leading-[130px] z-[999] relative text-white">LUTHFI <br>
                        GINTING.
                    </div>
                </div>
                <div class="self-start mt-[50px]">
                    <div class="desc text-4xl fonseca text-white mb-9">
                        Indonesian
                        <div class="text-primary">FULLSTACK</div>
                        Developer and <br> Editor
                    </div>
                    <div
                        class="more cursor-pointer pb-1 border-b-2 border-secondary max-w-fit flex items-center gap-[55px] gotham-medium text-xl text-secondary">
                        <div class="">More about me</div>
                        <i class="fa-solid fa-forward"></i>
                    </div>
                </div>
            </div>
        </div>
        <img src="<?php echo e(asset('images/background.png')); ?>"
            class="gw rata-background h-[820px] w-auto z-[-999] absolute bottom-[-42px] right-0 left-0 m-auto"
            alt="">
    </div>

    <div class="bg-bg2 relative top-[-131px] px-[180px] pt-[200px] pb-[250px] z-20">
        <div class="flex justify-between">
            <div class="about1 flex flex-col items-start w-2/5">
                <div class="gotham-light text-xl text-primary mb-5 relative left-[-12px]">&#x2022; About</div>

                <div class="gotham-bold text-3xl text-white leading-[42px] mb-5">High school student, who develops
                    application</div>

                <div class="gotham-medium text-xl text-[#EEEEEE] leading-[42px] mb-11">
                    I Study in a IT School, Based in indonesia, we learn technologies and development.
                </div>

                <div
                    class="cursor-pointer text-secondary text-xl gotham-medium flex items-center border-b-[2px] border-secondary max-w-fit">
                    <i class="mr-10">kodeintekno.com</i>
                    <i class="fa-solid fa-forward"></i>
                </div>

            </div>

            <div class="flex flex-col w-[45%]">
                <div class="about2">
                    <div class="gotham-bold text-3xl text-white leading-[42px] mb-5">Experience is the name everyone
                        gives
                        to
                        their mistakes.</div>

                    <div class="gotham-medium text-xl text-[#EEEEEE] leading-[42px] mb-11">
                        Start learning to develop when i went to high school, from website, mobile and fullstack
                        development.
                    </div>
                </div>

                <div class="flex justify-between items-center">
                    <div class="about3 flex gap-6 items-center">
                        <div class="fonseca text-[70px] text-primary">3</div>
                        <div class="gotham-bold text-2xl text-white"> Years of <br> Experience</div>
                    </div>

                    <div class="about4 flex gap-6 items-center">
                        <div class="fonseca text-[70px] text-primary">24</div>
                        <div class="gotham-bold text-2xl text-white"> Projects <br> Finished</div>
                    </div>
                </div>

            </div>
        </div>
        <div class="flex gap-[40px] absolute justify-center left-[180px] right-[180px] bottom-[-150px]">
            <div
                class="block1 cursor-pointer h-[300px] w-full duration-300 bg-bg1 hover:bg-secondary flex items-end justify-center pb-10 shadow-xl">
                <div class="flex gap-6">
                    <i class="text-4xl text-white fa-solid fa-laptop mt-4"></i>
                    <div>
                        <div class="text-white gotham-medium text-3xl mb-4">Website <br> Developer.</div>
                        <div class="text-xl gotham-light text-white">8 Project</div>
                    </div>
                </div>
            </div>

            <div
                class="block2 cursor-pointer h-[300px] w-full duration-300 bg-bg1 hover:bg-secondary flex items-end justify-center pb-10 shadow-xl">
                <div class="flex gap-6">
                    <i class="fa-solid fa-mobile-screen-button text-4xl text-white mt-5"></i>
                    <div>
                        <div class="text-white gotham-medium text-3xl mb-4">Mobile <br> Developer.</div>
                        <div class="text-xl gotham-light text-white">8 Project</div>
                    </div>
                </div>
            </div>

            <div
                class="block3 cursor-pointer h-[300px] w-full duration-300 bg-bg1 hover:bg-secondary flex items-end justify-center pb-10 shadow-xl">
                <div class="flex gap-6">
                    <i class="fa-solid fa-pen-ruler text-4xl text-white mt-5"></i>
                    <div>
                        <div class="text-white gotham-medium text-3xl mb-4">UI / UX <br> Design.</div>
                        <div class="text-xl gotham-light text-white">8 Project</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="h-screen bg-bg1 relative top-[-131px] flex align-center justify-center">
        <div class="fonseca text-[80px] text-white flex items-center">PAGE UNDER CONSTRUCTION</div>
    </div>

    <style>
        @font-face {
            font-family: Fonseca;
            font-weight: bold;
            src: url('<?php echo e(public_path('fonts/Fonseca.tff')); ?>');
        }

        @font-face {
            font-family: Gotham;
            font-weight: 700;
            src: url('<?php echo e(public_path('fonts/GothamBold.tff')); ?>');
        }

        @font-face {
            font-family: Gotham;
            font-weight: 500;
            src: url('<?php echo e(public_path('fonts/GothamBook.tff')); ?>');
        }

        @font-face {
            font-family: Gotham;
            font-weight: 600;
            src: url('<?php echo e(public_path('fonts/GothamMedium.tff')); ?>');
        }

        .dot::after {
            display: flex;
            justify-content: center;
            border-radius: 999px;
            left: 0;
            right: 0;
            height: 8px;
            margin: auto;
            width: 8px;
            position: absolute;
            content: '';
            background-color: #A25D50;
            /* display: block; */
        }

        .miring {
            transform: skewY(5deg);
            position: relative;
            top: -65px;
            height: 118vh;
        }

        .rata {
            transform: skewY(-5deg);
            position: relative;
            top: 65px
        }

        .rata-background {
            transform: skewY(-5deg);

        }

        .fonseca {
            font-family: 'Fonseca', sans-serif;
        }

        .gotham-bold {
            font-family: 'Gotham', sans-serif;
            font-weight: 700;
        }

        .gotham-light {
            font-family: 'Gotham', sans-serif;
            font-weight: 400;
        }

        .gotham-medium {
            font-family: 'Gotham', sans-serif;
            font-weight: 500;
        }
    </style>
    <script>
        ScrollReveal().reveal('.name', {
            delay: 100,
            distance: '50px',
            origin: 'left',
            duration: 1000
        });
        ScrollReveal().reveal('.ig', {
            delay: 200,
            distance: '80px',
            origin: 'bottom',
            duration: 1000
        });
        ScrollReveal().reveal('.linked', {
            delay: 300,
            distance: '80px',
            origin: 'bottom',
            duration: 1000
        });
        ScrollReveal().reveal('.git', {
            delay: 400,
            distance: '80px',
            origin: 'bottom',
            duration: 1000
        });
        ScrollReveal().reveal('.desc', {
            delay: 100,
            distance: '50px',
            origin: 'right',
            duration: 1000
        });
        ScrollReveal().reveal('.more', {
            delay: 400,
            distance: '50px',
            origin: 'right',
            duration: 1000
        });
        ScrollReveal().reveal('.gw', {
            delay: 100,
            duration: 1000
        });
        ScrollReveal().reveal('.about1', {
            delay: 100,
            distance: '50px',
            duration: 1000
        });
        ScrollReveal().reveal('.about2', {
            delay: 200,
            distance: '50px',
            duration: 1000
        });
        ScrollReveal().reveal('.about3', {
            delay: 200,
            distance: '50px',
            duration: 1000,
            origin: 'right'
        });
        ScrollReveal().reveal('.about4', {
            delay: 400,
            distance: '50px',
            duration: 1000,
            origin: 'right'
        });

        ScrollReveal().reveal('.block1', {
            delay: 300,
            distance: '50px',
            duration: 1000,
        });
        ScrollReveal().reveal('.block2', {
            delay: 400,
            distance: '50px',
            duration: 1000,
        });
        ScrollReveal().reveal('.block3', {
            delay: 500,
            distance: '50px',
            duration: 1000,
        });
    </script>
</body>

</html>
<?php /**PATH C:\Users\Luthfi\luthfirizky\resources\views/frontend/home.blade.php ENDPATH**/ ?>